#include "TCGenParticle.h"
#ifdef __CINT__
#pragma link C++ class TCGenParticle;
#endif
