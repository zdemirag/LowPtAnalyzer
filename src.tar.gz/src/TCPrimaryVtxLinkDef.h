/* 
 * File:   TCJetLinkDef.h
 * Author: Anton a.
 *
 * Created on May 19, 2010, 5:38 PM
 */

#include "TCPrimaryVtx.h"
#ifdef __CINT__
#pragma link C++ class TCPrimaryVtx;
#endif
