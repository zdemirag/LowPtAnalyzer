#include "TCPhoton.h"
#ifdef __CINT__
#pragma link C++ struct TCPhoton::CrystalInfo+;
#pragma link C++ class TCPhoton;
#endif
