/* 
 * File:   TCJetLinkDef.h
 * Author: Anton A.
 *
 * Created on May 19, 2010, 5:37 PM
 */

#include "TCJet.h"
#ifdef __CINT__
#pragma link C++ class TCJet;
#endif
