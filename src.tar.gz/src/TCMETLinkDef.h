/* 
 * File:   TCMETLinkDef.h
 * Author: Nate O. 
 *
 * Created on December 6 2010 8:24 PM
 */

#include "TCMET.h"
#ifdef __CINT__
#pragma link C++ class TCMET;
#endif
