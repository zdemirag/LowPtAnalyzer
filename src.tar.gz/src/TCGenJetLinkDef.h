/* 
 * File:   TCGenJetLinkDef.h
 * Author: Nate 0.
 *
 * Created on May 19, 2010, 5:37 PM
 */

#include "TCGenJet.h"
#ifdef __CINT__
#pragma link C++ class TCGenJet;
#endif
