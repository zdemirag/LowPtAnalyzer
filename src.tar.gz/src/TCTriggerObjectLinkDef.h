#include "TCTriggerObject.h"
#ifdef __CINT__
#pragma link C++ class TCTriggerObject;
#endif
