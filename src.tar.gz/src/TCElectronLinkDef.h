/* 
 * File:   TCElectronLinkDef.h
 * Author: Anton A.
 *
 * Created on May 19, 2010, 5:37 PM
 */

#include "TCElectron.h"
#ifdef __CINT__
#pragma link C++ class TCElectron;
#endif
