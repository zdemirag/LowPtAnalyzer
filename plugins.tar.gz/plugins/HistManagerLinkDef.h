#include "HistManager.h"
#ifdef __CINT__
#pragma link C++ class HistManager;
#endif
