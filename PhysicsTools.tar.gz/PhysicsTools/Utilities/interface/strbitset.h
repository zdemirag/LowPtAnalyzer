#warning "This has moved to PhysicsTools/SelectorUtils"
#include "PhysicsTools/SelectorUtils/interface/strbitset.h"
