#ifndef PhysicsTools_Constant_h
#define PhysicsTools_Constant_h
#include "PhysicsTools/Utilities/interface/Polynomial.h"

namespace funct {
  typedef Polynomial<0> Constant;
}

#endif
