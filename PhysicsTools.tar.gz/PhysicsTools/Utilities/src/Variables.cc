#include "PhysicsTools/Utilities/interface/Variables.h"

IMPLEMENT_VARIABLE(DefaultVariable);
IMPLEMENT_VARIABLE(X);
IMPLEMENT_VARIABLE(Y);
IMPLEMENT_VARIABLE(Z);
